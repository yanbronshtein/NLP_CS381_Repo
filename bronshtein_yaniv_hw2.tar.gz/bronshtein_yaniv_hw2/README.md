type python hw2.py in a linux/mac terminal 
<br>
You will be prompted to enter the directory of the file where the news.crawl.bz2 is located
<br>
Enter the full file path excluding the file name
